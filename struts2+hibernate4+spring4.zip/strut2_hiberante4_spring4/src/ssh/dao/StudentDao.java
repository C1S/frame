package ssh.dao;

import ssh.entity.Student;

public interface StudentDao extends BaseDao<Student>{

}

package ssh.dao.imp;

import ssh.entity.Student;

import org.springframework.stereotype.Repository;

import ssh.dao.StudentDao;

@Repository
public class StudentDaoImp extends BaseDaoImp<Student> implements StudentDao{

}

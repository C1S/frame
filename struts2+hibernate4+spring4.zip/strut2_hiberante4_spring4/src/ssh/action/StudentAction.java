package ssh.action;

import org.springframework.beans.factory.annotation.Autowired;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import ssh.dao.StudentDao;
import ssh.entity.Student;

public class StudentAction extends ActionSupport {

	@Autowired
	private StudentDao studentDao;
	
	private Student student;
	
	public String register(){
		System.out.println(studentDao);
		try{
		studentDao.save(student);
		ActionContext context = ActionContext.getContext();
		context.put("msg", "注册成功");
		}catch(Exception e){
			e.printStackTrace();
			return "registerErr";
		}
		return "register";
	}
	
	public String find(){
		Student student = studentDao.get(Student.class, 1);
		if(student==null){
			return "findErr";
		}
		else{
		ActionContext context = ActionContext.getContext();
		context.put("student", student);
		context.put("msg", "查询成功");
		return "find";
		}
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	
}
